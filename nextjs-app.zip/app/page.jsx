export default function Page() {
  return (
    <main style={{ padding: 20, fontFamily: 'sans-serif' }}>
      <h1>Next.js Blue/Green Demo</h1>
      <p>Version 1</p>
    </main>
  );
}